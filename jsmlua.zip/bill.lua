require "json"
-------------------------------------------------------------------------------
local function username(id)
    if not id then return 'nil' end
    local name = string.match(id, '%[[%w_]*:([%w_-]*)') or id
    if string.len(name) > 20 then
        return string.sub(name, 1, 9) .. '*' .. string.sub(name, -10)
    else
        return name
    end
end
-------------------------------------------------------------------------------
local difftime = function()
    local _t={}
    return function(t)
        local i=1
        while (t[i] and _t[i] == t[i]) do i=i+1 end
        if i > #t then return nil end
        _t = t
        return table.concat(t,':',i)
    end
end
-------------------------------------------------------------------------------
local function actor_uml(id, actor, html)
    local t={}
    local to_right = true
    local as, n = 0, 1
    local dir='r'
    if html then
        io.write('<h2>', username(id), '</h2><img uml="\n(*)')
    else
        io.write('@startuml\ntitle "', username(id), '"\n(*)')
    end
    local ts=''
    for i,v in ipairs(actor) do
        local s
        if n > 5 then n = -1 end
        if type(v) == 'table' then
            s={}
            for k,y in pairs(v) do -- stats
                if t[k] ~= y then table.insert(s, k..'='..y) end
            end
            if s and #s > 0 then
                t=v
                s = table.concat(s, ' ')
            else
                s=nil
            end
        elseif string.byte(v) == 91 then --'['  timestamp
            ts  = v
        else --leave reason
            t={}
            s = v
            n = -1
        end
        if s then
            dir= to_right and 'r' or 'l'
            if n == 0 then
                dir = 'd'
                to_right = not to_right
            end
            if html then
                io.write('-', dir, '-&gt;', ts, '&quot;', s, '&quot;')
            else
                io.write('-', dir, '->', ts, '"', s, '"')
            end
            io.write(' as ', as, '\n')
            as = as + 1
            n = n + 1
            ts = ''
        end
    end
    dir= to_right and 'r' or 'l'
    if html then
        io.write('-', dir, '-&gt;(*)"\n>\n')
    else
        io.write('-', dir, '->(*)\n@enduml\n')
    end
end

---------------------------------------------------------------------------
local function BILL ()
    local _rooms={}
    return {
        line = function(ts, roomId,  bill)
            _rooms[roomId] = _rooms[roomId] or {}
            local json = table.json(bill)
            if json.pub == 'new' or json.pub == 'delete' then
                --print(bill)
            elseif json.actor then
                local room = _rooms[roomId]
                for id,v in pairs(json.actor) do
                    room[id] = room[id] or {ts=difftime()}
                    ts = room[id].ts(ts)
                    if ts then table.insert(room[id], '['..ts..']') end
                    table.insert(room[id],v)
                end
            end
        end,

        html = function(outfile)
io.output(outfile)
io.write [[
<html><head>
<meta charset="UTF-8" />
<script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery/jquery-1.4.min.js"></script>
<script type="text/javascript" src="http://plantuml.com/jquery_plantuml.js"></script>
<script type="text/javascript" src="http://plantuml.com/rawdeflate.js"></script>
<link rel="stylesheet" type="text/css" href="../toc.css" />
<script src="../toc.js"></script>
<title>Jusmeeting 话单</title>
</head>
<body>
]]
for roomId, room in pairs(_rooms) do
    io.write(string.format("<hr><h1>%s</h1>", roomId))
    for id,v in pairs(room) do actor_uml(id, v, true) end
end
io.write[[</body></html>]]
end,

        uml = function(outfile)
            io.output(outfile)
            for id, actors in pairs(_rooms) do
                for k,v in pairs(actors) do actor_uml(k, v, false) end
            end
        end
    }
end
---------------------------------------------------------------------------
local bill = BILL()
--[[分析服务器的话单:
命令格式:
[roomId] logfile ...
]]
for i, file in ipairs(arg) do
    if pcall(io.input,file) then
        print(i..'>process', file)
        for line in io.lines() do
            if string.find(line, ': bill=') then
                local day, ts, id, json= string.match(line, "(%S+) (%S+) .* (%S+): bill=(.*)")
                if json and (not roomId or string.match(id, roomId)) then
                    day = string.gsub(day, '-','')
                    local hour,min,sec,ms = string.match(ts, "(%d%d):(%d%d):(%d%d)%.(%d%d%d)")
                    bill.line({day,hour,min,sec,ms}, id, json)
                end
            end
        end
    else
        roomId = file  --过滤 ROOM
    end
end
bill.html('bill.html')
