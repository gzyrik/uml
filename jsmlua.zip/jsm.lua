--lua jsm.lua [stats|seq|bill] 目录
local st = os.clock()
local lfs=require"lfs"
local attri = lfs.attributes(arg[2])
local logs={}
local dir = string.match(arg[0], '(.*)jsm.lua')
if attri.mode == 'directory' then
    for file in lfs.dir(arg[2]) do
        if string.match(file, 'mtc.*%.log$') then
            table.insert(logs, file)
        end
    end
    lfs.chdir(arg[2])
    -- 按修改时间排序
    table.sort(logs, function(f1, f2)
        return lfs.attributes(f1, 'modification') < lfs.attributes(f2, 'modification')
    end)
    dir = '../'..dir
else
    table.insert(logs, arg[2])
end
---
logs[0] = dir .. arg[1] .. '.lua'
arg = logs
dofile(arg[0])
st = (os.clock()- st)*1000
print('finish elapse', st..' ms')
