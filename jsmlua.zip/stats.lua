local difftime = function()
    local _t={}
    return function(t)
        local i=1
        while (_t[i] == t[i] and i <= #t) do i=i+1 end
        _t = t
        return table.concat(t,':',i)
    end
end
local function seq(qos, dt, ts, id, category)
    qos[id] = qos[id] or {}
    qos = qos[id]
    qos[category] = qos[category] or {}
    qos = qos[category]
    dt[id] = dt[id] or {}
    dt = dt[id]
    dt[category] = dt[category] or difftime()
    dt = dt[category]
    qos.x = qos.x or {}
    dt = dt(ts)
    table.insert(qos.x, dt)
    return qos
end

--SendStatistic: Packets:2558 RTT:5 Jitter:5 Lost:0 LostRatio:0 BitRate/BWE:33/1213
--RecvStatistic: Packets:16778 Jitter:1 Lost:0 LostRatio:0 BitRate/BWE:748/1511 
local network = function (qos, dt, ts, id, category, value)
    qos = seq(qos, dt, ts, id, category)
    for k, v in string.gmatch(value, "([%w/]+):([%w/]+)") do
        if string.find(k,'/') then
            if v== 'N/A' then v='0/0' end
            local k0, k1 = string.match(k, "(%w*)/(%w*)")
            local v0, v1 = string.match(v, "(%w*)/(%w*)")
            qos[k0] = qos[k0] or {}
            qos[k1] = qos[k1] or {}
            table.insert(qos[k0], v0)
            table.insert(qos[k1], v1)
        else
            if v== 'N/A' then v='0' end
            qos[k] = qos[k] or {}
            table.insert(qos[k], v)
        end
    end
end

--VideoSendingStats: Packets:1883 CaptureFr:17 FPS/IDR:8/3 Resolution:640x360[F|0|0] Bitrate/Setrate:24/800 QP:21 FecPrecent:0 
--BeSubscribedStats: Audio:true Video:[F|0|0|0] Screen:[0|0|0|0]
local sender = function (qos, dt, ts, id, category,value)
    if category == 'BeSubscribedStats' then return end
    qos = seq(qos, dt, ts, id, category)
    for k, v in string.gmatch(value, "([%w/]+):([%w/|%[%]]+)") do
        if k ~= 'Resolution' then
            if string.find(k,'/') then
                if v== 'N/A' then v='0/0' end
                local k0, k1 = string.match(k, "(%w*)/(%w*)")
                local v0, v1 = string.match(v, "(%w*)/(%w*)")
                qos[k0] = qos[k0] or {}
                qos[k1] = qos[k1] or {}
                table.insert(qos[k0], v0)
                table.insert(qos[k1], v1)
            else
                if v== 'N/A' then v='0' end
                qos[k] = qos[k] or {}
                table.insert(qos[k], v)
            end
        end
    end
end

--AudioReceivingStats: Packets:1842 BitRate:15.8
--VideoReceivingStats: Packets:9550 Bitrate:572 FPS/FIR:30/0 Resolution:640x360 RenderFR:29
--ScreenReceivingStats: Packets:674 Bitrate:115 FPS/FIR:4/1 Resolution:1440x896 RenderFR:5
--SubscribeStats: Audio:true Video:S2T14 Screen:S3T14
local recver = function (qos, dt, ts, id, category, value)
    if category == 'SubscribeStats' then return end
    qos = seq(qos, dt, ts, id, category)
    for k, v in string.gmatch(value, "([-%w/]+):([-%w/]+)") do
        if k ~= 'Resolution' then
            if string.find(k,'/') then
                if v== 'N/A' then v='0/0' end
                local k0, k1 = string.match(k, "(%w*)/(%w*)")
                local v0, v1 = string.match(v, "(%w*)/(%w*)")
                qos[k0] = qos[k0] or {}
                qos[k1] = qos[k1] or {}
                table.insert(qos[k0], v0)
                table.insert(qos[k1], v1)
            else
                if v== 'N/A' then v='0' end
                qos[k] = qos[k] or {}
                table.insert(qos[k], v)
            end
        end
    end
end

local function parse(qos, dt, ts, id, category, detail)
    if category == 'SendStatistic' or category == 'RecvStatistic' then
        network(qos, dt, ts, id, category, detail)
    elseif category == 'VideoSendingStats' or category == 'BeSubscribedStats' then
        sender(qos, dt, ts, id, category, detail)
    else
        recver(qos, dt, ts, id, category, detail)
    end
    return true
end

local function html(id, category, qos)
io.write([[<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <style type="text/css">
  .legendLayer .background {
    fill: rgba(255, 255, 255, 0.85);
    stroke: rgba(0, 0, 0, 0.85);
    stroke-width: 1;
}
  </style>
  <!-- script type="text/javascript" src="http://libs.baidu.com/jquery/2.0.0/jquery.min.js" /-->
  <!-- script type="text/javascript" src="http://apps.bdimg.com/libs/flot/0.8.2/jquery.flot.min.js" /-->
  <!--script type="text/javascript" src="https://cdn.bootcss.com/flot/0.8.3/jquery.flot.selection.js" /-->
  <script type="text/javascript" src="../flot.min.1.0.3.js"></script>
  <script type="text/javascript">
  $(function () {
]])

io.write('var datasets = {\n')
for k,v in pairs(qos) do
    if k ~= 'x' then
        io.write('"',k,'":{\nlabel:"',k,'",\ndata:[')
        local d={}
        for i,s in ipairs(v) do table.insert(d,"["..i..","..s.."]") end
        io.write(table.concat(d, ','), "]},\n")
    end
end
io.write("\n};\nvar times = [\n")
do
    local d={}
    for i,s in ipairs(qos.x) do table.insert(d,"["..i..',"'..s..'"]') end
    io.write(table.concat(d, ','), "];\n")
end

io.write([[
var i = 0;
$.each(datasets, function(key, val) {
    val.color = i;
    ++i;
});
var choiceContainer = $("#choices");
$.each(datasets, function(key, val) {
    var checked=''
    var type = val.label.toLowerCase();
    if (type == 'bitrate' || type == 'bwe') checked='checked';
    choiceContainer.append("<input type='checkbox' name='" + key +
    "' "+checked + " id='id" + key + "'></input>" +
    "<label for='id" + key + "'>"
    + val.label + "</label>");
});
choiceContainer.find("input").click(plotAccordingToChoices);
var plot;
var view;
var xaxis_from=0;
var xaxis_to=times.length;
var plot_options = {
    legend: {
        show: true,
        position: "nw"
    },
    series: {
        lines: {
            show: true
        },
        points: {
            show: false
        }
    },
    grid: {
        hoverable: true,
    },
    yaxis: {
        min: -10,
    },
    xaxis: {
        showTickLabels:'major', //none, major,endpoints, all
        ticks:times
    },
    selection: {
        mode: "xy",
        minSize: 10
    }
};
var view_options ={
    legend: {
        show: false
    },
    series: {
        lines: {
            show: true,
            lineWidth: 1
        },
        shadowSize: 0
    },
    xaxis: {
        ticks: [],
    },
    yaxis: {
        ticks: [],
        min: -10,
    },
    grid: {
        color: "#999"
    },
    selection: {
        mode: "xy",
        minSize: 10
    }
};
function getData(from,to) {
    var data = [];
    choiceContainer.find("input:checked").each(function () {
        var key = $(this).attr("name");
        var d = datasets[key];
        if (key && d) {
            data.push({
                color: d.color,
                label: d.label,
                data:  d.data.slice(from,to)});
        }
    });
    return data;
}
function plotAccordingToChoices() {
    var data = getData(xaxis_from, xaxis_to);
    if (data && data.length > 0) {
        plot = $.plot("#placeholder", data, plot_options);
        view = $.plot("#overview", data, view_options);
    }
}

plotAccordingToChoices();

$("<div id='tooltip'></div>").css({
    position: "absolute",
    display: "none",
    border: "1px solid #fdd",
    padding: "2px",
    "background-color": "#fee",
    opacity: 0.80
}).appendTo("body");

$("#placeholder").bind("plothover", function (event, pos, item) {
    if (item) {
        var x = item.datapoint[0].toFixed(2),
        y = item.datapoint[1].toFixed(2);

        $("#tooltip").html(item.series.label + "=" + y)
        .css({top: item.pageY+5, left: item.pageX+5})
        .fadeIn(200);
    } else {
        $("#tooltip").hide();
    }
});

$("#placeholder").bind("plotselected", function (event, ranges) {
    // clamp the zooming to prevent eternal zoom
    if (ranges.xaxis.to - ranges.xaxis.from < 0.00001) {
        ranges.xaxis.to = ranges.xaxis.from + 0.00001;
    }

    if (ranges.yaxis.to - ranges.yaxis.from < 0.00001) {
        ranges.yaxis.to = ranges.yaxis.from + 0.00001;
    }

    // do the zooming
    xaxis_from = ranges.xaxis.from;
    xaxis_to = ranges.xaxis.to;
    plot = $.plot("#placeholder", getData(xaxis_from, xaxis_to),
    $.extend(true, {}, plot_options, {
        xaxis: { min: ranges.xaxis.from, max: ranges.xaxis.to },
        yaxis: { min: ranges.yaxis.from, max: ranges.yaxis.to }
    })
    );

    // don't fire event on the overview to prevent eternal loop
    view.setSelection(ranges, true);
});
$("#overview").bind("plotselected", function (event, ranges) {
    plot.setSelection(ranges);
});

});
</script>
</head>
<body>
  <div id="content">
  <p id="choices"></p>
  <div id="placeholder" style="width:100%;height:80%;"></div>
  <div id="overview" style="width:100%; height:125px;"></div>
  </div>
</body>
</html>
]])
end
---------------------------------------------------------------------------
local _indexHtmls = {}
local _title = '会议媒体统计'
local function html_index()
    io.output("stats.html", "w+")
    io.write[[<html><head><style type="text/css">
.focus {list-style-type:none;margin:2px;background-color:purple;color:white;border:1px solid blue; }
u {cursor:pointer;}
</style><script type="text/javascript">
var indexHtmls = {
]]
for ts, innerHTML in pairs(_indexHtmls) do
    io.write('"', ts, '":"', innerHTML, '",\n')
end
io.write[[};
var lastTs, lastRef;
function statsByTs(ts){
    if (lastTs == ts) return;
    if (lastTs) lastTs.className='';
    document.getElementById("category").innerHTML = indexHtmls[ts.innerText];
    ts.className='focus';
    lastTs = ts;
}
function statsByRef(ref){
    if (lastRef == ref) return false;
    if (lastRef) lastRef.className='';
    ref.className = 'focus'; 
    lastRef = ref;
    return true;
}
</script><title>]]
io.write(_title)
io.write[[
</title></head><body>
<b>按结束时间(会议号)选择:</b>
]]
local endtimes = {}
for ts, _ in pairs(_indexHtmls) do
    table.insert(endtimes, ts)
end
table.sort(endtimes, function(a,b) return a >= b end)
for _, ts in ipairs(endtimes) do
    io.write('&emsp;<u onclick="return statsByTs(this)">', ts, '</u>\n')
end
io.write[[<hr>
<div id='category'></div>
<iframe name="showframe" width="100%" height="100%"></iframe>
</body></html>
]]
end
---------------------------------------------------------------------------
local categoryName = {
    AudioReceivingStats=' 远端音频接收',
    VideoReceivingStats='远端视频接收',
    SendStatistic='全局发送统计',
    RecvStatistic='全局接收统计',
    AudioSendingStats='本地音频发送',
    VideoSendingStats='本地视频发送',
}
---------------------------------------------------------------------------
local function JMP_STATS ()
    local QOS={}
    local DT={}
    return {
        html = function(endtime)
            local index = {}
            local innerHTML={}
            local roomId = ''
            for id, v in pairs(QOS) do
                for category, qos in pairs(v) do
                    local fname = endtime..'-'..string.gsub(id,'%*','')..'-'..category..".html"
                    io.output(fname)
                    html(id, category, qos, v)
                    if not string.find(category, 'ReceivingStats') then
                        local name = categoryName[category] or category
                        table.insert(innerHTML, '<b>'.. name .. ':</b>')
                        table.insert(innerHTML, [[<a onclick=\'return statsByRef(this)\' href=\']] .. fname .. [[\' target=\'showframe\'>]] .. id .. '</a>&emsp;')
                        if category == 'SendStatistic' or category == 'RecvStatistic' then roomId = '['..id ..']' end
                    else
                        index[category]  = index[category] or {}
                        index[category][id] = fname
                    end
                end
            end
            table.insert(innerHTML, '<br>')
            for category, files in pairs(index) do
                local name = categoryName[category] or category
                table.insert(innerHTML, '<b>'.. name .. ':</b>')
                for id, fname in pairs(files) do
                    table.insert(innerHTML, [[<a onclick=\'return statsByRef(this)\' href=\']] .. fname .. [[\' target=\'showframe\'>]] .. id .. '</a>&emsp;')
                end
                table.insert(innerHTML, '<br>')
            end
            _indexHtmls[endtime .. roomId] = table.concat(innerHTML, '')
        end,

        line = function(ts, id, category, detail) return parse(QOS, DT, ts, id, category, detail) end,

        uml = function(endtime) end
    }
end
---------------------------------------------------------------------------
local stamp 
local stats = JMP_STATS()
--分析客户端的媒体日志(JMP)
local function parseline(line, patten)
    --20160803T18:13:50.901+0800    JMP:  INFO: ...
    local day,hour,min,sec,info = string.match(line, "(%d*)T(%d%d):(%d%d):(%d%d%.%d%d%d).- JMP:  INFO: (.*)")
    if day and hour and min and sec and info then 
        --时间截
        stamp = day..'-'..hour..'-'..min..'-'..sec

        --检查 JMP 接口调用
        local ret, api=string.match(info, "(.-)=(Jmp_%w+)%(.*")
        if ret and api then 
            if api == 'Jmp_Client' then
                if ret == '0' then
                    print("*ERROR", line)
                else
                    if stats then stats.html(stamp) end
                    stats = JMP_STATS()
                    ret = string.find(info, 'VERSION:')
                    if ret then _title = string.sub(info, ret+8) end
                end
            elseif tonumber(ret) < 0 then
                print("  *ERROR*", line)
            end
        end

        -- 扫描统计
        if stats then
            local id, category, detail = string.match(info, "STATS: (%S*) (%w*): (.*)")
            if detail and (not patten or string.match(category, patten)) then
                stats.line({day,hour,min,sec}, id, category, detail)
            end
        end
    end
end
---------------------------------------------------------------------------
--[[分析服务器的话单:
命令格式:
[roomId] logfile ...
]]
local category
for i,file in ipairs(arg) do
    if pcall(io.input,file) then
        print(i..'>process', file)
        for line in io.lines() do
            if string.find(line, ' JMP:  INFO: ') then parseline(line, category) end
        end
    else
        category = file  --过滤 ROOM
    end
end
if stats then stats.html(stamp) end
html_index()
