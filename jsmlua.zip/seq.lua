require "json"
--[[
解析 JSM 信令 转化为序列图
-------------------------------------------------------------------------------]]
local _room --当前会场
-------------------------------------------------------------------------------
local difftime = function()
    local _t={}
    return function(t)
        local i=1
        while (t[i] and _t[i] == t[i]) do i=i+1 end
        if i > #t then return nil end
        _t = t
        return table.concat(t,':',i)
    end
end
-------------------------------------------------------------------------------
local function username(id)
    if not id then return 'nil' end
    local name = string.match(id, '%[[%w_]*:([%w_-]*)') or id
    if string.len(name) > 20 then
        return string.sub(name, 1, 9) .. '*' .. string.sub(name, -10)
    else
        return name
    end
end
-------------------------------------------------------------------------------
local function room_desc(str, room, cache)
    for k, v in pairs(room) do
        if v ~= _room[k] then
            if cache then _room[k] = v end
            table.insert(str, k..'='..v)
        end
    end
end
local function attr_desc(str, attr, actor)
    for k,v in pairs(attr) do
        if not actor then 
            table.insert(str, k..'='..v)
        elseif v ~= actor[k] then
            actor[k] = v
            table.insert(str, k..'='..v)
        end
    end
    return str
end
local function actor_desc(str, actor, cache)
    for id, attr in pairs(actor) do
        if type(attr) == 'table' then
            local actor
            if cache then
                _room.actor[id] = _room.actor[id] or {}
                actor = _room.actor[id]
            end
            attr = table.concat(attr_desc({}, attr, actor), ',')
        end
        table.insert(str, '\\n&emsp;<b>' .. username(id) .. ':</b>&ensp;' .. attr)
    end
end
local function join_desc(str, join, cache)
    if join.room then room_desc(str, join.room, cache) end
    if join.actor then actor_desc(str, join.actor) end
end
local function rep_desc(json) 
    local str={}
    if json.rep == 'join' then
        join_desc(str, json, true)
    else
        table.insert(str, json.ret)
    end
    return table.concat(str, ';')
end
local function pub_desc(json) 
    local str={}
    if json.pub == 'join' then
        join_desc(str, json, true)
    elseif json.pub == 'room' then
        room_desc(str, json.room, true)
    elseif json.pub == 'actor' then
        actor_desc(str, json.actor, true)
    elseif json.pub == 'leave' then
        actor_desc(str, json.actor, true)
    end
    return table.concat(str, ';')
end
local function req_desc(json)
    local str={}
    if json.req == "room" then
        room_desc(str, json.room)
    elseif json.req == "actor" then
        attr_desc(str, json.attr)
        for _, id in ipairs(json.actorId) do
            table.insert(str, username(id))
        end
    elseif json.req == "join" then
        if json.actor then _room.self = next(json.actor) end
        join_desc(str, json)
    end
    return table.concat(str, '; ')
end
-------------------------------------------------------------------------------
local _ROOM={} --所有会场
local _LINE=0  --当前行数
local function send(str, roomId, ts)
    local json = table.json(str)
    if json.req == 'heart' then return end
    _room = _ROOM[roomId] or {actor={},ts=difftime()}
    ts = _room.ts(ts)
    io.write("self -[#blue]-\\ &#34;", roomId, "&#34;: <b>", json.req, ":</b>&ensp;", req_desc(json), "\n")
    if ts then io.write("note left:", ts, "\n") end
    if _LINE == 0 or not _ROOM[roomId] then
        io.write("activate &#34;", roomId, "&#34;\n")
        _ROOM[roomId] = _room
    end
    _LINE = _LINE + 1
end
-------------------------------------------------------------------------------
local function recv(str, roomId, ts)
    local deactivate
    local json = table.json(str)
    if json.pub == 'heart' or json.pub == 'chat' then return end
    _room = _ROOM[roomId] or {actor={},ts=difftime()}
    ts = _room.ts(ts)
    if json.rep then
        io.write("self \\-[#blue]- &#34;", roomId, "&#34;: <b>", json.rep, ":</b>&ensp;", rep_desc(json), "\n")
        deactivate = json.rep == 'leave'
    else
        io.write("self <[#green]-o &#34;", roomId, "&#34;: <b>", json.pub, ":</b>&ensp;", pub_desc(json), "\n")
        deactivate = json.pub == 'leave' and _room.self and json.actor and json.actor[_room.self]
    end
    if ts then io.write("note left:", ts, "\n") end
    if deactivate then
        io.write("deactivate &#34;", roomId, "&#34;\n")
        _ROOM[roomId] = nil
        _LINE = 40
    elseif not _ROOM[roomId] or _LINE == 0 then
        io.write("activate &#34;", roomId, "&#34;\n")
        _ROOM[roomId] = _room
    end
    _LINE = _LINE + 1
end
-------------------------------------------------------------------------------
local function parseline(line)
    local day,hour,min,sec,ms,dir,roomId,json = string.match(line, "(%d*)T(%d%d):(%d%d):(%d%d)%.(%d%d%d).- JSM:  INFO: ([><])(.+): (.*)")
    if not dir then return end;
    if _LINE == 0 then
        io.write('<img uml="\nautonumber ', _LINE, '\n')
        for roomId, _ in pairs(_ROOM) do
            io.write('participant &#34;', roomId, '&#34;\n')
        end
        io.write'actor self #red\n'
    end
    if dir == '>' then 
        send(json, roomId, {day,hour,min,sec,ms})
    elseif dir == '<' then
        recv(json, roomId, {day,hour,min,sec,ms})
    end
    if _LINE > 40 then
        io.write'">\n'
        _LINE = 0
    end
end
-------------------------------------------------------------------------------
io.output("seq.html")
io.write [[
<html><head>
<script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery/jquery-1.4.min.js"></script>
<script type="text/javascript" src="http://plantuml.com/jquery_plantuml.js"></script>
<script type="text/javascript" src="http://plantuml.com/rawdeflate.js"></script>
</head>
<body>
]]
for i, file in ipairs(arg) do
    print(i..'>process', file)
    for line in io.lines(file) do
        if string.find(line, ' JSM:  INFO: ') then parseline(line) end
    end
end
if _LINE > 0 then io.write'">\n' end
io.write'</body></html>'
